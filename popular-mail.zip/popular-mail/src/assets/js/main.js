// Popular Mail — shared front-end behaviour
document.addEventListener('DOMContentLoaded', function () {

  // Mobile drawer
  var menuToggle = document.querySelector('.menu-toggle');
  var drawer = document.querySelector('.mobile-drawer');
  var closeDrawer = document.querySelector('.close-drawer');
  if (menuToggle && drawer) {
    menuToggle.addEventListener('click', function () {
      drawer.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  }
  if (closeDrawer && drawer) {
    closeDrawer.addEventListener('click', function () {
      drawer.classList.remove('open');
      document.body.style.overflow = '';
    });
  }
  if (drawer) {
    drawer.addEventListener('click', function (e) {
      if (e.target === drawer) {
        drawer.classList.remove('open');
        document.body.style.overflow = '';
      }
    });
  }

  // Inline search toggle (homepage magnifier -> jumps to search page)
  var searchToggle = document.querySelector('.search-toggle');
  if (searchToggle) {
    searchToggle.addEventListener('click', function () {
      window.location.href = 'search.html';
    });
  }

  // Duplicate ticker items for a seamless marquee loop
  var track = document.querySelector('.ticker-items');
  if (track && !track.dataset.cloned) {
    track.innerHTML += track.innerHTML;
    track.dataset.cloned = 'true';
  }

  // Newsletter form (static demo — wire to Mailchimp/ConvertKit/etc. in production)
  var form = document.querySelector('.newsletter-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var input = form.querySelector('input[type="email"]');
      var btn = form.querySelector('button');
      if (input && input.value) {
        btn.textContent = 'Subscribed';
        btn.disabled = true;
        input.disabled = true;
      }
    });
  }

  // Search filter pills (visual only in this static prototype)
  document.querySelectorAll('.search-filters button').forEach(function (btn) {
    btn.addEventListener('click', function () {
      document.querySelectorAll('.search-filters button').forEach(function (b) {
        b.classList.remove('active');
      });
      btn.classList.add('active');
    });
  });
});
