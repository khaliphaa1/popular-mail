module.exports = {
  url: "https://popularmail.ng",
  buildDate: new Date(),
};
