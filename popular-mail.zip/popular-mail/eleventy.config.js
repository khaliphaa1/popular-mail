const yaml = require("js-yaml");

module.exports = function (eleventyConfig) {
  // Allow global data files in _data/ to be written as YAML
  eleventyConfig.addDataExtension("yml", (contents) => yaml.load(contents));

  // Static assets pass straight through to the output folder
  eleventyConfig.addPassthroughCopy("src/assets");
  eleventyConfig.addPassthroughCopy("src/admin");
  eleventyConfig.addPassthroughCopy("src/robots.txt");
  eleventyConfig.addPassthroughCopy({ "admin/config.yml": "admin/config.yml" });

  // ---- Filters ----

  // Human-friendly date, e.g. "September 13, 2026"
  eleventyConfig.addFilter("readableDate", (dateObj) => {
    if (!dateObj) return "";
    const d = new Date(dateObj);
    return d.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  });

  // Time string, e.g. "11:00 AM"
  eleventyConfig.addFilter("readableTime", (dateObj) => {
    if (!dateObj) return "";
    const d = new Date(dateObj);
    return d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
  });

  // ISO string for datetime attributes / JSON-LD
  eleventyConfig.addFilter("isoDate", (dateObj) => {
    if (!dateObj) return "";
    return new Date(dateObj).toISOString();
  });

  // RFC-822 date string required by RSS <pubDate>
  eleventyConfig.addFilter("rssDate", (dateObj) => {
    if (!dateObj) return "";
    return new Date(dateObj).toUTCString();
  });

  // Turn "Northern Nigeria" -> "northern-nigeria"
  eleventyConfig.addFilter("slugify", (str) => {
    if (!str) return "";
    return String(str)
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "");
  });

  // Take the first N items of an array
  eleventyConfig.addFilter("limit", (arr, n) => (arr || []).slice(0, n));

  // Skip the first N items of an array (for pagination-free "rest of list" sections)
  eleventyConfig.addFilter("skip", (arr, n) => (arr || []).slice(n));

  // CSS-safe class name for a category tag, e.g. "Northern Nigeria" -> "tag-north"
  eleventyConfig.addFilter("tagClass", (category) => {
    const map = {
      "News": "tag-news", "Politics": "tag-politics", "Business": "tag-business",
      "Metro": "tag-metro", "Kano": "tag-kano", "Northern Nigeria": "tag-north",
      "World": "tag-world", "Entertainment": "tag-entertainment", "Sports": "tag-sports",
      "Technology": "tag-technology", "Education": "tag-education", "Health": "tag-health",
      "Opinion": "tag-opinion", "Features": "tag-features", "Interviews": "tag-features",
      "Videos": "tag-videos"
    };
    return map[category] || "tag-news";
  });

  // Short label for a social platform icon, e.g. "Facebook" -> "f", "X" -> "X"
  eleventyConfig.addFilter("socialAbbr", (platform) => {
    const map = { "Facebook": "f", "X": "X", "Instagram": "ig", "YouTube": "yt", "TikTok": "tt", "WhatsApp": "wa" };
    return map[platform] || String(platform).slice(0, 2);
  });

  // Look up an author's full profile by name (matches CMS relation field)
  eleventyConfig.addFilter("findAuthor", (authors, name) => {
    return (authors || []).find((a) => a.data.name === name);
  });

  // ---- Collections ----

  eleventyConfig.addCollection("article", (collectionApi) => {
    return collectionApi.getFilteredByTag("article").sort((a, b) => b.date - a.date);
  });

  eleventyConfig.addCollection("author", (collectionApi) => {
    return collectionApi.getFilteredByTag("author");
  });

  eleventyConfig.addCollection("northArticles", (collectionApi) => {
    return collectionApi
      .getFilteredByTag("article")
      .filter((item) => item.data.category === "Kano" || item.data.category === "Northern Nigeria")
      .sort((a, b) => b.date - a.date);
  });

  return {
    dir: {
      input: "src",
      includes: "_includes",
      data: "_data",
      output: "_site",
    },
    markdownTemplateEngine: "njk",
    htmlTemplateEngine: "njk",
  };
};
